package core;

/**
 * Created by Nicolas on 28/09/2016.
 */

public interface Evoluable {
	public void evoluer();
	public void desevoluer();
}
